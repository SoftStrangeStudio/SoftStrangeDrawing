---
name: ssd-packaging
description: "Handle packaging for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Packaging

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Inspect actual artifacts for identity/version, ABI, SDK, release flags, permissions, focus/VR metadata, signature and size. Verify APK v2 independently: default apksigner may select v3 at minSDK32. Check native-library ZIP alignment separately. The existing Flatpak script may use privileged Docker on Mac and network/runtime installation; disclose that path before authorized execution.

## Owners

- [tools/apk_preflight.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/apk_preflight.py)
- [tools/build-flatpak.sh](/Users/angelberger/Documents/SoftStrangeDrawing/tools/build-flatpak.sh)
- [packaging/flatpak/com.softstrange.Drawing.json](/Users/angelberger/Documents/SoftStrangeDrawing/packaging/flatpak/com.softstrange.Drawing.json)

## Validation and continuity

Bind SHA256, artifact path and all failed checks. Flatpak export/install in emulation is not native Linux launch acceptance; installed APK is not store approval.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
