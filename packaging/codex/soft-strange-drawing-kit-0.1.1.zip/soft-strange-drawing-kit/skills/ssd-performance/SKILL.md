---
name: ssd-performance
description: "Handle performance and reliability for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Performance and reliability

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Measure CPU/GPU frame time, memory, loading and thermal behavior on each claimed headset with dense imports, curves, gallery switching and sustained drawing. Diagnostic FPS on desktop or short idle Quest samples are not qualification. Current automatic pose recording and developer endpoint are off in non-development APKs; use appropriate bounded device logs/profiling instead.

## Owners

- [Assets/SoftStrange/Runtime/Services/DiagnosticsService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/DiagnosticsService.cs)
- [Assets/SoftStrange/Runtime/Services/VectorOutlineService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/VectorOutlineService.cs)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)

## Validation and continuity

Define device/workload/duration and pass criteria before measuring, report spikes and limitations, and retain exact build identity. Investigate crash/missing-script/SDK errors rather than calling logs clean.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
