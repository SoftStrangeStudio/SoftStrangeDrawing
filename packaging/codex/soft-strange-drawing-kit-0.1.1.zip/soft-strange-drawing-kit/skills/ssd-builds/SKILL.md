---
name: ssd-builds
description: "Handle build execution for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Build execution

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Reuse canonical methods in a fresh Unity process per target. Review APK enables diagnostics; build --release builds the non-development candidate then signs QuestRelease using the existing identity. BuildMac changes project target/settings; preserve/reconcile those effects. Preserve earlier candidates when needed for comparison, write bounded logs and identify the exact output. Do not rebuild every platform for a small change.

## Owners

- [Assets/SoftStrange/Editor/ProjectBuilder.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Editor/ProjectBuilder.cs)
- [tools/headset.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/headset.py)
- [tools/build_delivery.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/build_delivery.py)

## Validation and continuity

Require process success plus artifact existence and configuration checks. Latest output path alone does not prove the requested method ran or that device behavior passed.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
