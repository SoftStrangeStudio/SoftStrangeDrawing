---
name: ssd-hands
description: "Handle hand interaction for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Hand interaction

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Ray origin is the thumb/index midpoint; aim is wrist-forward with 75 ms directional smoothing, independent of finger curl. Preserve hand-size-relative entry/release hysteresis, rearming, debounce, system-gesture suppression and tracking-loss cancellation. Controller trigger/grip fallback shares the interaction contract. Do not replace wrist aim with pinch-pose or finger aim while adjusting thresholds.

## Owners

- [Assets/SoftStrange/Runtime/HandInput.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/HandInput.cs)
- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)
- [Assets/SoftStrange/Runtime/PinchButton.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/PinchButton.cs)

## Validation and continuity

Check both hands, single activation per pinch, slow close/release, wrist held steady while fingers curl, two-hand handoff and interrupted grabs. Source/desktop checks cannot prove physical pinch comfort.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
