---
name: ssd-platforms
description: "Handle platform configuration for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Platform configuration

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Quest uses ARM64 IL2CPP/Vulkan, min SDK32/target34 and Meta AR components. Frame is a separate ARM64 min29 candidate with no Meta AR session/camera, Valve controller priority and generic OpenXR alpha blending; restore Quest settings afterward. Mac/Linux studio removes mobile components and uses desktop input. Flatpak is x86_64 desktop packaging, not proof of native Frame compatibility.

## Owners

- [Assets/SoftStrange/Editor/ProjectBuilder.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Editor/ProjectBuilder.cs)
- [Assets/SoftStrange/Editor/DesktopBuildIsolation.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Editor/DesktopBuildIsolation.cs)
- [Assets/SoftStrange/Editor/QuestManifest.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Editor/QuestManifest.cs)
- [Assets/SoftStrange/Runtime/SteamFramePassthroughFeature.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/SteamFramePassthroughFeature.cs)
- [docs/steam-frame-and-flatpak.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/steam-frame-and-flatpak.md)

## Validation and continuity

Inspect saved/merged configuration per target. Keep canonical XR settings referenced once; do not enable conflicting desktop/mobile loaders or serialize unsupported disabled scripts.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
