---
name: ssd-release
description: "Handle release management for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Release management

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Freeze one exact candidate with source state, version/code, hash, signature and test evidence. Historical 0.3.1 package checks passed but UX redesign and physical acceptance remain separate. Older sections in readiness/validation mention test signing/palm aim; reconcile affected stale text against current evidence rather than reintroducing resolved blockers. Keep prior candidates for rollback; do not downgrade installed data blindly.

## Owners

- [docs/store/readiness.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/readiness.md)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)
- [docs/store/listing-draft.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/listing-draft.md)

## Validation and continuity

Assess technical, UX, hardware and publisher gates separately. A release report can say not-ready. Approval to build/sign is not approval to upload, submit or publish.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
