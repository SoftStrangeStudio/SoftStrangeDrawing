---
name: ssd-workspace
description: "Handle drawing workspace for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Drawing workspace

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

ReferenceSheet owns one/two-hand transforms and Locked state; GuideService owns the independently placed grid. Preserve grid position/visibility through reference lock, image change and app recenter. OS origin changes and app recenter are different operations. Placement is session-local; there is no verified persistent spatial-anchor feature. Keep deliberate editing separate from locked physical drawing.

## Owners

- [Assets/SoftStrange/Runtime/ReferenceSheet.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/ReferenceSheet.cs)
- [Assets/SoftStrange/Runtime/Services/GuideService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/GuideService.cs)
- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)

## Validation and continuity

Exercise move/rotation/resize, release one hand, lock/unlock, grid selection/finish, image changes and recenter. Check cancellation before changing transforms.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
