---
name: ssd-router
description: "Handle request routing for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Request routing

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Interpret normal conversational requests, including typos, by intended outcome and current scope. Select one primary domain and only affected neighbors from the registry. A requested explanation/review remains read-only; implementation or build authority does not imply store publication. Tool route resolves source ownership, not natural-language intent. Subskills are instructions, not permission to spawn agents.

## Owners

- [AGENTS.md](/Users/angelberger/Documents/SoftStrangeDrawing/AGENTS.md)
- [memory.md](/Users/angelberger/Documents/SoftStrangeDrawing/memory.md)

## Validation and continuity

For pinch feedback route hands plus workspace/interface; gallery feedback routes references plus interface; release build routes builds plus packaging/signing. Preserve earlier authorized scope and avoid needless confirmations.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
