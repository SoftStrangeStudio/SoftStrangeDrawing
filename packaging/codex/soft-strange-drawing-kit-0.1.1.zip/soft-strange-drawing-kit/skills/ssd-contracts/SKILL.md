---
name: ssd-contracts
description: "Handle shared contracts for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Shared contracts

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

CommandService/AppCommand/RuntimeState are shared command/state contracts. Follow UI -> Execute -> service state -> Refresh/PublishState, and preserve the command queue main-thread boundary for HTTP. Review builds bind developer transport to loopback. InputAllowed/focus owns mutation permission; no new backend is required.

## Owners

- [Assets/SoftStrange/Runtime/Services/AppServices.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/AppServices.cs)
- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)
- [Assets/SoftStrange/Runtime/UploadServer.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/UploadServer.cs)
- [tools/mcp_debugger.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/mcp_debugger.py)

## Validation and continuity

When a field/command changes, check its registration, physical/UI caller, HTTP/MCP schema and published state. Do not fork synonymous APIs or expose developer control in the release to simplify tests.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
