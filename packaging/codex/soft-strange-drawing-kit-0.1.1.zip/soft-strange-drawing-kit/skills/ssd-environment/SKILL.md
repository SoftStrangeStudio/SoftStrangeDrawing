---
name: ssd-environment
description: "Handle environment for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Environment

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

The authored house is the desktop simulation environment; Quest passthrough is a distinct runtime mode. Preserve UserEye, DrawingDeskAnchor, ReferenceAnchor and HouseOrigin anchors and the shared geometry for paired views. Inspect camera view, lighting, material contrast and scale rather than judging Blender renders as Quest evidence. Blender scripts depend on their installed bpy API; check compatibility before batch generation.

## Owners

- [Assets/SoftStrange/Runtime/Plugins/HouseSimulationPlugin.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Plugins/HouseSimulationPlugin.cs)
- [Assets/SoftStrange/Runtime/Services/ReferenceModelService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/ReferenceModelService.cs)
- [tools/blender/soft_strange_house_kit.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/blender/soft_strange_house_kit.py)
- [tools/blender/build_reference_pairs.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/blender/build_reference_pairs.py)
- [Assets/SoftStrange/Environment](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Environment)

## Validation and continuity

Capture the actual Unity room from the user view and the working desk. Original .blend/FBX/provenance must agree. Rendered desktop footage is labeled simulation.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
