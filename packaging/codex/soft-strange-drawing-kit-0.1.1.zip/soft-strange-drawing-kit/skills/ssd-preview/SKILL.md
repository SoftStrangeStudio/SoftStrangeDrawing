---
name: ssd-preview
description: "Handle local preview for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Local preview

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

BuildMac produces the native desktop studio; bind the running version before review. Desktop controls: mouse selects, right drag looks, WASD moves, wheel scales, Space locks, R recenters and Escape returns home. Existing loopback API/MCP is the command bridge; do not add another server. Check port ownership before connecting; do not stop another app to free a port.

## Owners

- [Assets/SoftStrange/Runtime/Plugins/DesktopInputPlugin.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Plugins/DesktopInputPlugin.cs)
- [Assets/SoftStrange/Runtime/Plugins/HouseSimulationPlugin.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Plugins/HouseSimulationPlugin.cs)
- [tools/mcp_debugger.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/mcp_debugger.py)
- [Assets/SoftStrange/Runtime/UploadServer.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/UploadServer.cs)

## Validation and continuity

Read live version/platform/frame progression and use native visible controls for UI claims. The helper API is not a substitute for physical hand testing.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
