---
name: ssd-feedback
description: "Handle feedback and comfort for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Feedback and comfort

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Use quiet original audio, subtle highlights and restrained decorative animation to communicate selectable/grabbed/locked states. Preserve mute/volume/reduced-motion preferences. System focus loss pauses audio and interactions. Do not use continuous audio or decorative motion as the only indication of an essential state.

## Owners

- [Assets/SoftStrange/Runtime/Services/ComfortAudioService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/ComfortAudioService.cs)
- [Assets/SoftStrange/Runtime/Services/ReferenceModelService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/ReferenceModelService.cs)
- [Assets/SoftStrange/Runtime/CozyGraphics.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/CozyGraphics.cs)
- [Assets/SoftStrange/Runtime/StudioView.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/StudioView.cs)
- [tools/create_comfort_audio.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/create_comfort_audio.py)

## Validation and continuity

Check muted startup persistence, resume without bursts, reduced-motion behavior, readable indicators and human headset comfort. Waveform validity alone is not acoustic acceptance.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
