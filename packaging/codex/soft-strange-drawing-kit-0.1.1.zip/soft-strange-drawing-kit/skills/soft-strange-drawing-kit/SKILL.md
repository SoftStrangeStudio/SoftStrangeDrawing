---
name: soft-strange-drawing-kit
description: "Develop, review, extend, preview, build and prepare releases of Soft Strange Drawing. Use for this project's Unity app, Quest interaction, reference art, local simulation and platform delivery."
---

# Soft Strange Drawing Kit

Bind [the project](../../references/project.md), read its current AGENTS.md and memory.md, and interpret the user's request naturally. No formal change-request packet is required. Latest user scope overrides old proposals.

Use [domains.json](../../registry/domains.json) to choose one primary owner and only affected neighboring subskills. Read their SKILL.md files by path. All 27 domains are available independently; do not preload them. Request routing is semantic; the helper's file routing is an ownership aid, not an intent classifier.

Examples: pinch stability -> hands, workspace; remove central menus -> interface, product, workspace; improve room lighting -> environment, visual-review; rebuild signed Quest APK -> builds, packaging, signing; assess publication -> release, store-submission. Read-only review/planning does not authorize implementation. Do not spawn subagents merely because subskills exist.

Inspect relevant owners before editing. Preserve existing services, commands, dirty work, assets and platform separation. Current requested direction is interaction-driven drawing with almost no persistent UI; the previous large drawers remain implemented until redesigned. Contextual style/grid controls still need to be discoverable.

Use [kit.py](../../scripts/kit.py) for inspect, file ownership routing, environment checks, known tool command plans, plugin validation and loopback API reads. Use tool --execute only for the current authorized operation. Project tools perform real work; the plugin is not another game runtime, UI system, server or package uploader. See [tool methods](../../references/tools.md).

Follow the [maintenance workflow](../../references/maintenance.md): after meaningful accepted decisions or verified changes update the affected existing project record and, only when needed, the canonical plugin methods/ownership. Do not modify installed caches or create a competing tracker. Plugin installation is not a live skill reload or a validation of every app integration.

Report result, changed owners, relevant evidence/limits and the next unmet action. Build, runtime, device acceptance, delivery and Meta publication are separate states. Signing uses the existing private identity without disclosing it. Do not uninstall apps, upload/submit/publish or modify GitHub without applicable explicit user authorization.
