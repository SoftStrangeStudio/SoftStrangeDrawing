---
name: ssd-product
description: "Handle product and intent for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Product and intent

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Translate ordinary, typo-heavy feedback into the smallest intended outcome. Preserve the physical-paper drawing purpose. The requested direction is almost no persistent UI: direct manipulation, subtle indicators, a deliberate lock/edit transition and contextual adjustments. The exact redesigned controls remain proposed until implemented and reviewed. Do not turn feedback into mandatory change forms or add accounts, cloud services, pen capture or persistent spatial anchors without a scoped request.

## Owners

- [memory.md](/Users/angelberger/Documents/SoftStrangeDrawing/memory.md)
- [docs/interaction-flow.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/interaction-flow.md)
- [docs/store/listing-draft.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/listing-draft.md)

## Validation and continuity

Separate user decisions, proposals, implemented behavior and acceptance. Put durable agreed product changes in memory.md; do not promote a suggestion to an accepted requirement.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
