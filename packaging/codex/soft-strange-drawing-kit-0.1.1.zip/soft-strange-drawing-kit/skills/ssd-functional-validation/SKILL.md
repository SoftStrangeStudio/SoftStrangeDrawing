---
name: ssd-functional-validation
description: "Handle functional validation for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Functional validation

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Use existing command/state API and manual native UI for a focused end-to-end journey. Commands originate in CommandService and must reach the same authoritative state as physical controls. Cover cross-domain transitions only when affected: select/place/lock, grid independence, styles, imports and focus. Lifecycle checks belong here: dashboard during a pinch, focus/tracking loss, headset removal, sleep/wake and OS recenter. Verify input/audio pause, canceled grabs and a fresh gesture after return. Do not create a second validation database or require formal work packets.

## Owners

- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)
- [tools/mcp_debugger.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/mcp_debugger.py)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)

## Validation and continuity

Distinguish command success, subsequent observable state, actual UI clicks and physical-device acceptance. Record exact artifact/source and failures in docs/validation.md when a validation record changes.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
