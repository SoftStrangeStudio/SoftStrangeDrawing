---
name: ssd-visual-review
description: "Handle visual review for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Visual review

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Bind the fresh Mac build/source or exact Quest APK. Capture consistent home/library/placement/locked/palette/grid states; compare the same camera and selected reference. Existing capture.start emits local frame PNGs; it is a bounded capture request, not a background recorder. Review text overlap, contrast, outline occlusion and desk visibility.

## Owners

- [Assets/SoftStrange/Runtime/StudioView.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/StudioView.cs)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)

## Validation and continuity

Inspect the pixels and actually navigate the states you report. Keep desktop simulation, Quest capture, before/after and proposed mockups explicitly labeled; never call generated art gameplay footage.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
