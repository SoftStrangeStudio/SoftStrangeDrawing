---
name: ssd-build-environment
description: "Handle build environment for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Build environment

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Check Unity 6000.3.11f1 and installed target modules/SDK tools against current source. The project uses OpenXR, XR Hands and Meta packages, plus Valve utilities for Frame. Another Unity 2020 licensing client previously blocked batch startup; the known build invocation uses -licensingIpc SoftStrangeBuild6000. Leave unrelated editors running. Archive only identical unreferenced XR simulation duplicates via the existing helper.

## Owners

- [ProjectSettings/ProjectVersion.txt](/Users/angelberger/Documents/SoftStrangeDrawing/ProjectSettings/ProjectVersion.txt)
- [Packages/manifest.json](/Users/angelberger/Documents/SoftStrangeDrawing/Packages/manifest.json)
- [tools/headset.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/headset.py)

## Validation and continuity

Run the read-only doctor, inspect build logs for the actual first failure, and report missing tools without silently installing/upgrading dependencies.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
