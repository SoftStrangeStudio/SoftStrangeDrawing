---
name: ssd-handoff
description: "Handle continuation handoff for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Continuation handoff

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Use existing project records for continuity instead of creating another tracker. A useful handoff identifies the exact workspace/dirty state, latest accepted intent, changed owners, working commands, artifact hashes, observed failures and next useful action. A small task needs a short note, not a document pack.

## Owners

- [memory.md](/Users/angelberger/Documents/SoftStrangeDrawing/memory.md)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)
- [docs/store/readiness.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/readiness.md)

## Validation and continuity

Clearly separate proposed, implemented, compiled, runtime-tested, device-accepted and delivered results. Never include credentials or equate installed plugin availability with hot-loaded skills in the current chat.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
