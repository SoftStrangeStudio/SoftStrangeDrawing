---
name: ssd-store-submission
description: "Handle store submission for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Store submission

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Prepare public support/privacy, publisher app identity, price, ratings, tested devices/play modes, rights/AI disclosures and truthful media. Check current official Meta requirements when doing submission work; do not rely on a copied static policy checklist. Preserve the offline/no-account/no-ads/no-analytics behavior unless explicitly changed. Developer captures/pose logs and desktop house footage are not release telemetry or genuine Quest media.

## Owners

- [docs/store/listing-draft.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/listing-draft.md)
- [docs/store/privacy-policy-draft.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/privacy-policy-draft.md)
- [docs/store/third-party-notices.txt](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/third-party-notices.txt)
- [art/store/manifest.json](/Users/angelberger/Documents/SoftStrangeDrawing/art/store/manifest.json)

## Validation and continuity

Read back dashboard metadata and uploaded artifact identity only during explicitly authorized submission work. Legal acceptance and publication remain separate human decisions where required; never modify GitHub as a side effect.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
