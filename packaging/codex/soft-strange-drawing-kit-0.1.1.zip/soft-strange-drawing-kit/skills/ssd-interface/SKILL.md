---
name: ssd-interface
description: "Handle interface for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Interface

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Own world-space canvases, contextual palettes, discovery and selection feedback. Latest requested direction is interaction-driven with minimal persistent controls. The existing UI still uses large central drawers; inspect a live render before claiming redesign. The 2026-11-02 Mac captures show art behind controls, weak selected states, four-item paging and a persistent dock. Use readable backing behind text, subtle reference affordances and clear mode feedback; avoid a new hidden-gesture vocabulary. DesktopInputPlugin/HandInput own presses: do not add InputSystemUIInputModule, which previously double-fired buttons.

## Owners

- [Assets/SoftStrange/Runtime/StudioView.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/StudioView.cs)
- [Assets/SoftStrange/Runtime/CozyGraphics.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/CozyGraphics.cs)
- [Assets/SoftStrange/Runtime/PinchButton.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/PinchButton.cs)

## Validation and continuity

Render home, browsing, placement, locked drawing and contextual adjustments. Click real controls in the Mac preview, then physically verify Quest reach/readability. Set generated RectTransform center anchors/pivots explicitly.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
