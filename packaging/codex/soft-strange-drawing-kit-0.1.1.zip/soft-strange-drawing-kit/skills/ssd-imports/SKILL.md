---
name: ssd-imports
description: "Handle image import and storage for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Image import and storage

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Native import and private Images/Inbox storage are customer paths; the loopback upload API is development/desktop only. Current limits are PNG/JPEG, 12 MB, 4096 pixels per axis and 100 imported images. Validate dimensions before decoded allocation, stage writes and preserve the old reference on failure. The current service has no established per-image removal workflow; treat removal as missing until implemented. Do not automate the file explorer; use the existing API for automated transfers and manual Quest picker acceptance.

## Owners

- [Assets/SoftStrange/Runtime/Services/ImageLibraryService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/ImageLibraryService.cs)
- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)
- [Assets/SoftStrange/Runtime/UploadServer.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/UploadServer.cs)
- [Assets/SoftStrange/Plugins/Android](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Plugins/Android)
- [tools/NativeReferencePicker.mm](/Users/angelberger/Documents/SoftStrangeDrawing/tools/NativeReferencePicker.mm)

## Validation and continuity

Verify import success/cancel/corrupt/oversize cases, restart persistence, thumbnails and any newly implemented removal path. Do not infer native picker success from API upload success.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
