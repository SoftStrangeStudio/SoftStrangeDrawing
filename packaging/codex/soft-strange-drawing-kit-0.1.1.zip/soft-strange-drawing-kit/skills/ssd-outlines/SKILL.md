---
name: ssd-outlines
description: "Handle outline processing for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Outline processing

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Output pure white recolorable ink with transparent interiors/backgrounds; generated colored fill is not drawing-reference output. Preserve AI originals and run the existing cleanup filter. Runtime owns solid/dotted, opacity, width, color, edge threshold and automatic Bezier conversion. Keep the 2048-path bound and full-solid fallback for dense imports; never silently display truncated curves. Exported vectors are normalized paths/control points, not captured physical pencil strokes.

## Owners

- [Assets/SoftStrange/Runtime/Services/VectorOutlineService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/VectorOutlineService.cs)
- [Assets/SoftStrange/Shaders](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Shaders)
- [tools/prepare_line_art.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/prepare_line_art.py)
- [tools/process_reference_library.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/process_reference_library.py)

## Validation and continuity

Check visible ink, white RGB, clear borders, alpha, solid/dotted continuity and dense-input fallback. Inspect the rendered result and retained provenance, not only file existence.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
