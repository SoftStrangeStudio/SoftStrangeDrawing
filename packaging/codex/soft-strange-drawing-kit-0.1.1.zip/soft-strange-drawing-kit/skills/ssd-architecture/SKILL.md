---
name: ssd-architecture
description: "Handle architecture for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Architecture

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

DrawingApp owns authoritative state and lifecycle. ServiceRegistry exposes services; IAppPlugin supplies Initialize/Tick/Dispose. Extend those seams rather than creating another app controller, input system, UI framework or command bus. Trace initialization, ownership and disposal before adding a service. Shared DrawingApp edits require checking the specific consumers they affect.

## Owners

- [Assets/SoftStrange/Runtime/DrawingApp.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/DrawingApp.cs)
- [Assets/SoftStrange/Runtime/Services/AppServices.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/AppServices.cs)

## Validation and continuity

Compile and exercise initialization/disposal plus the affected command path. Update the ownership registry when a real source owner moves.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
