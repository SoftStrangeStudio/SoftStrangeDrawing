---
name: ssd-context
description: "Handle context updater for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Context updater

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Maintain knowledge as part of authorized work, not as a background job. After a meaningful accepted decision update only its existing authoritative record: memory.md for product/architecture/preferences, docs/validation.md for tested evidence and limits, docs/store/readiness.md for release gates. Update registry ownership/workflows only when those actually change. No formal change request is required. Preserve original request wording only when needed to disambiguate intent.

## Owners

- [memory.md](/Users/angelberger/Documents/SoftStrangeDrawing/memory.md)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)
- [docs/store/readiness.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/readiness.md)

## Validation and continuity

Remove or qualify contradicted entries, avoid duplicates and do not copy live project progress into installed plugin cache. Changes to plugin source require validation and supported reinstall; never hand-edit caches or global Codex memory.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
