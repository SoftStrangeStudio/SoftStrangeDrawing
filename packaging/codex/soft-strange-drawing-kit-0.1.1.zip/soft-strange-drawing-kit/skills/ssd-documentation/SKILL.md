---
name: ssd-documentation
description: "Handle documentation checks for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Documentation checks

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Check linked source paths, command names, ownership, evidence dates and conflicting state claims. Source/build/runtime/package/device/user/store states are separate. Existing historical sections can stay historical but must not imply resolved signing or pointer issues are current. Keep private data, raw pose logs and signing credentials out of docs.

## Owners

- [memory.md](/Users/angelberger/Documents/SoftStrangeDrawing/memory.md)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)
- [docs/store/readiness.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/store/readiness.md)

## Validation and continuity

Run plugin check and inspect changed doc links. Say when evidence is stale or missing; do not update acceptance dates merely because a file was reread.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
