---
name: ssd-signing
description: "Handle signing and identity for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Signing and identity

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Use the existing dedicated release identity outside the repo at ~/.local/share/SoftStrangeDrawing/signing. Never read/print/copy password metadata into context, artifacts or logs; use the canonical signing helper. Never replace the key or routinely pass --create. Back up private signing material securely only to a user-approved destination. The public certificate fingerprint may be recorded in evidence.

## Owners

- [tools/sign_release.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/sign_release.py)
- [tools/apk_preflight.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/apk_preflight.py)

## Validation and continuity

Verify output signatures, public fingerprint, non-debuggable input and zip alignment. Preserve the intermediate candidate. Installation with a changed certificate requires a separate data-preserving decision.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
