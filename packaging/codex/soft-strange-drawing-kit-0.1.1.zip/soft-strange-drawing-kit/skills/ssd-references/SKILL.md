---
name: ssd-references
description: "Handle reference library for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Reference library

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

ImageLibraryService owns catalog entries, stable IDs, selected view and thumbnail lifetime. There are 60 AI illustrations plus 60 paired model subjects (120 side/top views); imported counts are device-local and must not inflate shipped-content claims. Keep AI illustrations distinct from actual orthographic model views. Unload/release thumbnail resources without destroying the selected texture.

## Owners

- [Assets/SoftStrange/Runtime/Services/ImageLibraryService.cs](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Runtime/Services/ImageLibraryService.cs)
- [Assets/SoftStrange/Resources/ReferenceCatalog.txt](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Resources/ReferenceCatalog.txt)
- [Assets/SoftStrange/Resources/PairedCatalog.txt](/Users/angelberger/Documents/SoftStrangeDrawing/Assets/SoftStrange/Resources/PairedCatalog.txt)

## Validation and continuity

Check category membership, stable saved selection, side/top pairing, missing/corrupt assets and gallery paging. Preserve immutable art/source originals and provenance.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
