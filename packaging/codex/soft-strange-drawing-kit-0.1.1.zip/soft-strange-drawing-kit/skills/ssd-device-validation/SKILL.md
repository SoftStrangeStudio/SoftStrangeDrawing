---
name: ssd-device-validation
description: "Handle device validation for Soft Strange Drawing in its bound Unity project; load for requests in this app domain."
---

# Device validation

Read the shared [project binding](../../references/project.md) and this domain's entry in [domains.json](../../registry/domains.json). Read only affected neighbors, not the entire plugin.

Confirm ADB serial/model, package identity and APK hash before installation. Use install -r to retain data. New release signatures cannot update earlier test-signed installs: explain the mismatch, preserve data and ask before uninstalling. Existing headset.py validate targets the review APK and expects its development endpoint; it must not be used to certify a release without adapting the checks. Frame deployment requires an explicit Lepton endpoint; a non-Quest ARM64 device alone is not enough identity proof.

## Owners

- [tools/headset.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/headset.py)
- [tools/steam_frame.py](/Users/angelberger/Documents/SoftStrangeDrawing/tools/steam_frame.py)
- [docs/validation.md](/Users/angelberger/Documents/SoftStrangeDrawing/docs/validation.md)

## Validation and continuity

Verify launch/focus/process, XR/passthrough and logs, then request direct confirmation for stereo/comfort/gestures. Do not auto-connect guessed network endpoints or claim acceptance from install success.

Use the [local helper](../../scripts/kit.py) to inspect owners and tool plans. Its default tool mode only prints a command; execution requires explicit --execute and task authorization. Apply the shared [maintenance workflow](../../references/maintenance.md) after meaningful authorized changes.
