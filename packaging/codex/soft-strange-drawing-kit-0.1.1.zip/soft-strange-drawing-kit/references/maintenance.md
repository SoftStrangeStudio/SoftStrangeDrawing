# Maintain knowledge while doing authorized work

1. Read the current request and relevant domain owners. Interpret ordinary requests directly; ask only when an unresolved decision changes the consequential action.
2. For explanation/review/planning, return findings without silently editing project records. For authorized implementation, preserve current work and perform only the scoped change and necessary verification.
3. After meaningful accepted product/architecture/preference changes, reconcile the existing memory.md entry. After actual checks, reconcile docs/validation.md with exact source/build, result, evidence path and limitations. After a release gate changes, reconcile docs/store/readiness.md. Existing records own state; do not introduce another progress database or copy raw pose logs.
4. Change canonical plugin source only when methods, contracts, ownership or routing really change. Prefer a correction over appended rules. Do not rewrite safeguards from a feature request, broaden authorization, or rewrite the plugin every turn. Do not modify global Codex memory unless separately requested.
5. Validate changed skills with the installed skill-creator validator and run kit.py check plus relevant helper checks. Bump .codex-plugin/plugin.json version for changed installed plugin behavior, then reinstall through codex plugin add soft-strange-drawing-kit@personal --json. Do not hand-edit ~/.codex/plugins/cache.
6. Read back the installed version/enabled state. A fresh Codex chat or reload may be needed for discovery. Project AGENTS.md links the canonical source so work can still use the maintained methods in the current chat. Do not claim universal automatic skill invocation or hot reload.

Never store secrets in the registry or notes. The user has authorized this plugin to maintain app-specific knowledge during its use; that is not authorization to publish, uninstall, change accounts or modify GitHub.
