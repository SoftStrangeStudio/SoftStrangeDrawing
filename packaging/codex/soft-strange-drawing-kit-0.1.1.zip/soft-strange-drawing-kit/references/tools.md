# Local helper methods

Canonical helper: /Users/angelberger/plugins/soft-strange-drawing-kit/scripts/kit.py. Python standard library only; no service or dependency installation.

- `python3 scripts/kit.py inspect interface`: domain owners, related domains, tools and authoritative records.
- `python3 scripts/kit.py route Assets/SoftStrange/Runtime/HandInput.cs`: domain ownership for exact files/directories; semantic intent routing remains the agent's job.
- `python3 scripts/kit.py doctor`: read-only environment presence, Unity version and artifact inventory; does not read signing files, contact devices or run Unity.
- `python3 scripts/kit.py tool build-release`: print the canonical command and side effects without executing.
- `python3 scripts/kit.py tool --execute build-release`: perform the authorized build/sign operation. Tool execution does not bypass approval requirements.
- `python3 scripts/kit.py tool --serial DEVICE install-release`: plan installation on the explicit serial. Execution checks Quest model first; never uninstall automatically. A signature mismatch is a user/data decision.
- `python3 scripts/kit.py api state`: read the existing loopback API. `commands` and `events` are also supported. This is unavailable in mobile release builds by design. The underlying mcp_debugger.py remains the existing stdio MCP bridge.
- `python3 scripts/kit.py check`: validate manifests, domain links, project owners, command entrypoints and cross-domain references without building or changing the app.

Only documented tools are executable. No shell evaluation, arbitrary subprocess command, guessed remote endpoint, credential inspection, automatic publish, or app uninstall helper is provided. Forwarded arguments follow `--`; the default mode only prints the plan. Required serial/endpoint values must be supplied to execute target-specific tools. Default APK inspection/signing targets the Quest release/candidate paths from the project.

Build methods reuse tools/headset.py, ProjectBuilder and build_delivery.py. Individual direct Unity builds use fresh processes and version-specific licensing IPC. Before desktop/direct builds, inspect stale simulation settings and archive only identical unreferenced copies using build_delivery.archive_stale_simulation_settings if needed. Do not execute this archive during a read-only review.

Frame and native Linux runtime acceptance remain unproven until tested on their actual targets. The existing Frame deploy script only excludes some wrong devices; confirm a genuine user-specified Lepton endpoint before using it. Flatpak on macOS can invoke privileged Docker and install runtimes; the plan describes these effects before execution.

The helper is not natural-language automation and does not decide a release GO. Run task-relevant checks, record evidence and report limitations through the owning skills.

Image filtering and store-art tools use the verified bundled Python configured as art_python in registry/project.json; its Pillow/NumPy/ReportLab/PDFium imports were checked. System Python may lack these dependencies. If the runtime moves, refresh its path using the workspace dependency loader instead of installing packages globally.
