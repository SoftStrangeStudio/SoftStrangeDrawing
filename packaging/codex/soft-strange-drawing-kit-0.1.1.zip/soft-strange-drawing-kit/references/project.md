# Project binding

Default workspace: `/Users/angelberger/Documents/SoftStrangeDrawing`. Resolve a caller-specified checkout before using it; helper `--project-root` must precede its subcommand. Verify ProjectSettings/ProjectVersion.txt and Assets/SoftStrange/Runtime/DrawingApp.cs exist. Do not assume a different Unity checkout is equivalent.

Unity 6000.3.11f1, Android ARM64 IL2CPP, OpenXR/XR Hands/Meta. Quest scene is Assets/SoftStrange/Scenes/Drawing.unity. Canonical owners and tool methods are in registry/domains.json and registry/tools.json; current state lives in the project, not in this plugin.

Product: offline MR references for drawing with a physical pencil/pen on paper. White recolorable transparent outline assets, matched side/top model studies, direct manipulation, deliberate lock/edit, independent grid, contextual style controls, hand input and controller fallback. Latest user direction favors minimal persistent UI and subtle indicators. Do not claim a specific redesigned interaction is implemented merely because it was proposed in chat.

Read memory.md for conventions, docs/validation.md for dated evidence, docs/store/readiness.md for release gates. Current captures from the 2026-11-02 Mac review are under builds/ux-review-20261102; compare against live source before treating them as current. The review found central translucent menus overlapping art, weak selection indicators, slow paging and desk/reference misalignment. Desktop visuals do not prove Quest stereo/comfort.

The current dedicated release identity remains outside the repository. Tooling must not open identity.json, print passwords, invent credentials or replace a key. Package/certificate fingerprints are public evidence. The existing release APK and version/code are observations to verify, not permanent defaults for future releases.

Use existing read-only connectors/CLI where suitable. No file explorer automation. No app startup hook, background updater, new network listener, scheduler or extra MCP server is installed by this plugin.
