#!/usr/bin/env python3
"""Domain inspection and explicit project-tool execution; no background service."""
import argparse
import importlib.util
import json
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
from urllib.parse import urlparse
from urllib.request import ProxyHandler, build_opener

PLUGIN = Path(__file__).resolve().parents[1]


def read(name):
    return json.loads((PLUGIN / 'registry' / name).read_text())


def emit(value):
    print(json.dumps(value, indent=2), flush=True)


def bind(root):
    root = root.expanduser().resolve()
    for marker in ['ProjectSettings/ProjectVersion.txt', 'Assets/SoftStrange/Runtime/DrawingApp.cs']:
        if not (root / marker).is_file():
            raise ValueError('Not the expected Soft Strange Drawing project: ' + str(root / marker))
    return root


def domain_info(root, ident, domains):
    entry = domains[ident]
    return dict(id=ident, **entry, skill_path=str(PLUGIN / entry['skill']),
                owners=[{'path': str(root / p), 'exists': (root / p).exists()} for p in entry['sources']])


def tool_plan(args, root, profile, tools):
    entry = tools[args.name]
    android = Path(profile['unity']).parents[3] / 'PlaybackEngines/AndroidPlayer'
    values = dict(root=str(root), unity=profile['unity'], python=sys.executable,
                  art_python=profile['art_python'],
                  adb=str(android / 'SDK/platform-tools/adb'),
                  blender=shutil.which('blender') or '/Applications/Blender.app/Contents/MacOS/Blender',
                  serial=args.serial or '<serial>', target=args.target or '<target>')
    extra = args.arguments
    if extra and extra[0] == '--':
        extra = extra[1:]
    if extra and args.name not in {'prepare-line-art', 'build-pairs', 'apk-check', 'validate-review'}:
        raise ValueError('This tool has a fixed command. Extra arguments are not accepted.')
    argv = [s.format(**values) for s in entry['argv']] + extra
    missing = [r for r in entry['requires'] if not getattr(args, r)]
    plan = {'tool': args.name, 'effect': entry['effect'], 'cwd': str(root), 'argv': argv,
            'display_command': shlex.join(argv), 'missing_parameters': missing,
            'executed': False}
    if not args.execute:
        emit(plan)
        return
    if missing:
        raise ValueError('Execution requires: ' + ', '.join('--' + r for r in missing))
    if args.name in {'prepare-line-art'} and len(extra) < 2:
        raise ValueError('Line-art conversion requires explicit source and destination paths.')
    if args.name == 'install-release':
        # The raw release install uses no developer endpoint and never uninstalls.
        model = subprocess.check_output([values['adb'], '-s', args.serial, 'shell',
                                         'getprop', 'ro.product.model'], text=True, timeout=10).strip()
        if 'Quest' not in model:
            raise ValueError('Expected an explicitly selected Quest, got ' + model)
        if not (root / profile['release_artifact']).is_file():
            raise ValueError('Signed release APK is missing; build and inspect it first.')
    emit(plan)
    # No shell; subprocess return codes propagate. Never retry destructive actions.
    subprocess.run(argv, cwd=root, check=True)
    emit({'tool': args.name, 'executed': True, 'exit_code': 0,
          'limits': 'Command completed; inspect its result before claiming app/device/store acceptance.'})


def check(root, profile, domains, tools):
    errors = []
    manifest = json.loads((PLUGIN / '.codex-plugin/plugin.json').read_text())
    if manifest.get('skills') != './skills/':
        errors.append('Plugin skills root is not the known directory')
    seen = set()
    for ident, entry in domains.items():
        if not (PLUGIN / entry['skill']).is_file():
            errors.append('Missing domain skill: ' + ident)
        for neighbor in entry['neighbors']:
            if neighbor not in domains:
                errors.append('Unknown neighbor: ' + ident + ' -> ' + neighbor)
        for source in entry['sources']:
            if not (root / source).exists():
                errors.append('Missing owner: ' + ident + ' -> ' + source)
        for tool in entry['tools']:
            if tool not in tools:
                errors.append('Unknown tool: ' + ident + ' -> ' + tool)
            elif ident not in tools[tool]['domains']:
                errors.append('Tool ownership mismatch: ' + ident + ' -> ' + tool)
    for file in (PLUGIN / 'skills').glob('*/SKILL.md'):
        text = file.read_text()
        front = re.match(r'^---\n(.*?)\n---\n', text, re.S)
        if not front:
            errors.append('Missing frontmatter: ' + str(file))
            continue
        name = re.search(r'^name:\s*(.+)$', front.group(1), re.M)
        if not name or name.group(1) in seen:
            errors.append('Missing/duplicate skill name: ' + str(file))
        else:
            seen.add(name.group(1))
        for target in re.findall(r'\]\(([^)]+)\)', text):
            if '://' in target or target.startswith('#'):
                continue
            path = Path(target.split('#')[0])
            if not path.is_absolute():
                path = file.parent / path
            if not path.exists():
                errors.append('Broken skill link: ' + str(file.relative_to(PLUGIN)) + ' -> ' + target)
    for name, tool in tools.items():
        for domain in tool['domains']:
            if domain not in domains:
                errors.append('Unknown tool domain: ' + name + ' -> ' + domain)
        for arg in tool['argv']:
            if arg.startswith(('tools/', 'packaging/')) and not (root / arg).exists():
                errors.append('Missing tool entrypoint: ' + arg)
        if not tool.get('effect'):
            errors.append('Missing side-effect description: ' + name)
    if not (PLUGIN / 'skills/soft-strange-drawing-kit/SKILL.md').exists():
        errors.append('Main router is missing')
    emit({'plugin': manifest['name'], 'version': manifest['version'], 'domain_count': len(domains),
          'skill_count': len(seen), 'tool_count': len(tools), 'errors': errors,
          'passed': not errors, 'limits': 'Structural checks only; no app build, device test or publication.'})
    return 1 if errors else 0


def main():
    profile, domains, tools = read('project.json'), read('domains.json'), read('tools.json')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project-root', type=Path, default=Path(profile['root']))
    sub = parser.add_subparsers(dest='action', required=True)
    inspect = sub.add_parser('inspect', help='Read domain ownership, boundaries and record locations')
    inspect.add_argument('domain', nargs='?', choices=domains)
    route = sub.add_parser('route', help='Map existing project source paths to owners; not semantic intent routing')
    route.add_argument('files', nargs='+')
    sub.add_parser('doctor', help='Read-only project/environment presence check; no credential reads')
    sub.add_parser('check', help='Validate plugin structure and existing source/tool links')
    tool = sub.add_parser('tool', help='Print a tool plan; execution is opt-in')
    tool.add_argument('--execute', action='store_true')
    tool.add_argument('--serial')
    tool.add_argument('--target')
    tool.add_argument('name', choices=tools)
    tool.add_argument('arguments', nargs=argparse.REMAINDER)
    api = sub.add_parser('api', help='Read an existing loopback app API; never starts a server')
    api.add_argument('resource', choices=['state', 'commands', 'events'])
    api.add_argument('--endpoint', default='http://127.0.0.1:8787')
    args = parser.parse_args()
    root = bind(args.project_root)
    if args.action == 'inspect':
        emit({'project': str(root), 'records': profile['records'], 'domains':
              [domain_info(root, ident, domains) for ident in ([args.domain] if args.domain else domains)]})
    elif args.action == 'route':
        matches = {}
        for path in args.files:
            file = (root / path).resolve()
            if not file.is_relative_to(root):
                raise ValueError('Source path is outside the bound project')
            if not file.exists():
                raise ValueError('Source path does not exist: ' + str(file))
            owners = []
            for ident, entry in domains.items():
                if any(file == root / p or ((root / p).is_dir() and file.is_relative_to(root / p))
                       for p in entry['sources']):
                    owners.append(ident)
            matches[str(file.relative_to(root))] = owners
        emit({'owners': matches, 'note': 'Choose primary owner semantically; shared files may have several consumers.'})
    elif args.action == 'doctor':
        unity = Path(profile['unity'])
        android = unity.parents[3] / 'PlaybackEngines/AndroidPlayer'
        paths = {'unity': unity, 'art_python': Path(profile['art_python']), 'adb': android / 'SDK/platform-tools/adb',
                 'aapt': android / 'SDK/build-tools/36.0.0/aapt',
                 'apksigner': android / 'SDK/build-tools/36.0.0/apksigner',
                 'mac_player': root / 'builds/Mac/Soft Strange Drawing.app',
                 'release_apk': root / profile['release_artifact']}
        emit({'project': str(root), 'unity_version': (root / 'ProjectSettings/ProjectVersion.txt').read_text().strip(),
              'paths': {k: {'path': str(v), 'exists': v.exists()} for k, v in paths.items()},
              'python_modules': {k: importlib.util.find_spec(k) is not None for k in ['PIL', 'numpy']},
              'host_commands': {k: shutil.which(k) is not None for k in ['blender', 'flatpak-builder', 'docker']},
              'limits': 'Presence only. No credential files opened, Unity started or device contacted.'})
    elif args.action == 'check':
        return check(root, profile, domains, tools)
    elif args.action == 'tool':
        tool_plan(args, root, profile, tools)
    elif args.action == 'api':
        url = urlparse(args.endpoint)
        if url.scheme != 'http' or url.hostname not in {'127.0.0.1', 'localhost', '::1'} or url.username or url.password:
            raise ValueError('Only the existing credential-free HTTP loopback API is supported')
        if url.path not in {'', '/'} or url.query or url.fragment:
            raise ValueError('Endpoint must be a plain loopback origin')
        opener = build_opener(ProxyHandler({}))
        with opener.open(args.endpoint.rstrip('/') + '/api/' + args.resource, timeout=4) as response:
            emit(json.load(response))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print(str(error), file=sys.stderr)
        sys.exit(1)
